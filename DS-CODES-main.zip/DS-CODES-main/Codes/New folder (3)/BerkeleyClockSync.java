public class BerkeleyClockSync {
    public static void main(String[] args) {
        int serverTime = 100;
        int[] clientTimes = {97, 102, 98, 105};

        System.out.println("Initial Times:");
        System.out.println("Server: " + serverTime);
        for (int i = 0; i < clientTimes.length; i++) {
            System.out.println("Client " + (i + 1) + ": " + clientTimes[i]);
        }

        int totalTime = serverTime;
        for (int time : clientTimes) {
            totalTime += time;
        }

        int avgTime = totalTime / (clientTimes.length + 1);

        System.out.println("\nAverage Time: " + avgTime);
        int serverOffset = avgTime - serverTime;
        System.out.println("\nTime Offsets (to be applied):");
        System.out.println("Server: " + serverOffset);

        int[] adjustedClientTimes = new int[clientTimes.length];
        for (int i = 0; i < clientTimes.length; i++) {
            int offset = avgTime - clientTimes[i];
            adjustedClientTimes[i] = clientTimes[i] + offset;
            System.out.println("Client " + (i + 1) + ": " + offset);
        }

        System.out.println("\nSynchronized Times:");
        System.out.println("Server: " + (serverTime + serverOffset));
        for (int i = 0; i < adjustedClientTimes.length; i++) {
            System.out.println("Client " + (i + 1) + ": " + adjustedClientTimes[i]);
        }
    }
}
